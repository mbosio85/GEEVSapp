#!/bin/bash

GATK=path_to/GenomeAnalysisTK.jar
REF=path_to/hg19.fasta
BAMS=path_to/bamset.list
OUTF=path_to/GEEVS_user_pipeline
PROBE=path_to/enrichment_kit_probes_file.bed
CPU=number_of_cpu_cores

################################################################
## GATK MultiSample Call
################################################################

## make initial multisample calling,both snps and indels
java -jar $GATK -R $REF -T UnifiedGenotyper -I $BAMS -nt $CPU -o multisampleInitialCall.vcf -A DepthPerAlleleBySample --intervals $PROBE -glm BOTH

## seprate snps and indels from main multisample call vcf file
java -jar $GATK -R $REF -T SelectVariants --variant multisampleInitialCall.vcf -o multisampleInitialCall.snps.vcf -selectType SNP -L $PROBE
java -jar $GATK -R $REF -T SelectVariants --variant multisampleInitialCall.vcf -o multisampleInitialCall.indels.vcf -selectType INDEL -L $PROBE

## variant recalibration : snps only
java -jar $GATK -T VariantRecalibrator -R $REF -input multisampleInitialCall.snps.vcf -recalFile multisampleInitialCall.snps.vcf.recal -tranchesFile multisampleInitialCall.snps.vcf.tranches   -resource:hapmap,known=false,training=true,truth=true,prior=15.0 hapmap_3.3.hg19.vcf -resource:omni,known=false,training=true,truth=false,prior=12.0 1000G_omni2.5.hg19.vcf -resource:dbsnp,known=true,training=false,truth=false,prior=2.0 dbsnp_138.hg19.vcf -resource:1000G,known=false,training=true,truth=false,prior=10.0 1000G_phase1.snps.high_confidence.hg19.vcf -an QD -an MQRankSum -an ReadPosRankSum -an FS  -mode SNP -tranche 100.0 -tranche 99.9 -tranche 99.0 -tranche 90.0 -rscriptFile recalibrate_SNP_plots.R --target_titv 3.0 -L $PROBE

## apply recalibration : snps only
java -jar $GATK -T ApplyRecalibration -R $REF -input multisampleInitialCall.snps.vcf -tranchesFile multisampleInitialCall.snps.vcf.tranches -recalFile multisampleInitialCall.snps.vcf.recal -o multisampleInitialCall.snps.recalibrated.filtered.vcf --ts_filter_level 99.9 -mode SNP -L $PROBE

## grep passed snps from the recalibration vcf
egrep 'PASS|^#' multisampleInitialCall.snps.recalibrated.filtered.vcf > multisampleInitialCall.snps.recalibrated.filtered.clean.vcf

## variant Evaluation
java -jar $GATK -T VariantEval -R $REF --dbsnp dbsnp_138.hg19.vcf -o report.multisampleInitialCall.snps.recalibrated.filtered.clean.vcf --eval multisampleInitialCall.snps.recalibrated.filtered.clean.vcf -l INFO --downsampling_type NONE

## variant recalibration : indels only
java -jar $GATK -T VariantRecalibrator -R $REF -input multisampleInitialCall.indels.vcf -recalFile multisampleInitialCall.indels.vcf.recal -tranchesFile multisampleInitialCall.indels.vcf.tranches  --maxGaussians 4 -resource:mills,known=true,training=true,truth=true,prior=12.0 Mills_and_1000G_gold_standard.indels.hg19.vcf -an FS -an ReadPosRankSum -an MQRankSum -tranche 100.0 -tranche 99.9 -tranche 99.0 -tranche 90.0 -mode INDEL -rscriptFile recalibrate_INDEL_plots.R -L $PROBE


## apply recalibration : indels only
java -jar $GATK -T ApplyRecalibration -R $REF -input multisampleInitialCall.indels.vcf -tranchesFile multisampleInitialCall.indels.vcf.tranches -recalFile multisampleInitialCall.indels.vcf.recal -o multisampleInitialCall.indels.recalibrated.filtered.vcf --ts_filter_level 99.9 -mode INDEL -L $PROBE

## grep passed indels from the recalibration vcf
egrep 'PASS|^#' multisampleInitialCall.indels.recalibrated.filtered.vcf > multisampleInitialCall.indels.recalibrated.filtered.clean.vcf

## variant evaluation : indels only
java -jar $GATK -T VariantEval -R $REF --dbsnp dbsnp_138.hg19.vcf -o report.multisampleInitialCall.indels.recalibrated.filtered.clean.vcf --eval multisampleInitialCall.indels.recalibrated.filtered.clean.vcf -l INFO --downsampling_type NONE


################################################################
## Prepare GEEVS files for uploading
################################################################
## convert your vcf(s) files to geevs format
perl $OUTF/bin/convert_to_geevs_format.pl vcf_files.txt 
## this vcf_files.txt should contain the recalibrated filtered clean vcf files with complete path, one vcf file per line
## your output files will be generated in yout input file location with the ".converted" suffix added
## now you need to run the following script on your ".converted" output file(s)
perl $OUTF/bin/prepare_geevs_vcf.pl multisampleInitialCall.snps.recalibrated.filtered.clean.vcf.converted $OUTF/header/vcfheader.txt geevs_variants_to_submit.vcf
perl $OUTF/bin/prepare_geevs_vcf.pl multisampleInitialCall.indels.recalibrated.filtered.clean.vcf.converted $OUTF/header/vcfheader.txt geevs_indel_variants_to_submit.vcf

## force call variants on each position of geevs region file
java -jar $GATK -R $REF -T UnifiedGenotyper -nt $CPU -I $BAMS -o geevs_locus.vcf -L geevs_locus.gatk.bed --output_mode EMIT_ALL_SITES

## prepare transformed sample depth of cov file to upload
perl $OUTF/bin/prepare_sample_dcov_file.pl geevs_locus.vcf
## your ouput file will be created in the same input file location and the file name will be geevs_locus.vcf.sample_dcov_file.txt
## this is the other file you need to upload along with the geevs variants vcf file

